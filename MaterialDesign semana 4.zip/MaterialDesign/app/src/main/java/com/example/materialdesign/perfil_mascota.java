package com.example.materialdesign;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class perfil_mascota extends Fragment {

    private ArrayList<Mascota> fotos;
    private RecyclerView rv_foto_mascota;
    public mascota_perfil_adaptador adaptador;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_perfil_mascota, container, false);

        rv_foto_mascota = (RecyclerView) v.findViewById(R.id.rv_foto_mascota);

        GridLayoutManager glm = new GridLayoutManager(getActivity(), 3);
        rv_foto_mascota.setLayoutManager(glm);

        inicializaDatos();
        inicializaAdaptador();

        return v;
    }


    public void inicializaAdaptador(){
        adaptador = new mascota_perfil_adaptador(fotos, getActivity());
        rv_foto_mascota.setAdapter(adaptador);
    }

    public void inicializaDatos() {
        fotos = new ArrayList<Mascota>();
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 15));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 14));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 13));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 12));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 11));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 10));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 9));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 8));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 7));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Simpatico", 6));
    }
}