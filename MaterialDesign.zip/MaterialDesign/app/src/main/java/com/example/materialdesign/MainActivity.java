package com.example.materialdesign;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TabLayout tab_Layout;
    private ViewPager viewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        tab_Layout = (TabLayout) findViewById(R.id.tab_Layout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        setUpViewPager();

        //Validación
        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item_rank:
                Intent intent = new Intent(this, ranking.class);
                startActivity(intent);
                break;
            case R.id.item_contacto:
                Intent i = new Intent(this, contacto.class);
                startActivity(i);
                break;
            case R.id.item_acerca:
                Intent intent1 = new Intent(this, desarrollador.class);
                startActivity(intent1);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private ArrayList<Fragment> agregarFragments() {
        ArrayList<Fragment> fragments = new ArrayList<>();

        fragments.add(new mascotas());
        fragments.add(new perfil_mascota());

        return fragments;
    }

    public void setUpViewPager () {
        viewPager.setAdapter(new PageAdapter(getSupportFragmentManager(), agregarFragments()));
        tab_Layout.setupWithViewPager(viewPager);

        tab_Layout.getTabAt(0).setIcon(R.drawable.icons8_dog_100);
        tab_Layout.getTabAt(1).setIcon((R.drawable.icons8_dog_park_16));

    }
}