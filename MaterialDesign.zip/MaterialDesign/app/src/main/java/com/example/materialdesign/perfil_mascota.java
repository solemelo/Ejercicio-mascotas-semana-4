package com.example.materialdesign;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class perfil_mascota extends Fragment {

    private ArrayList<Mascota> fotos;
    private RecyclerView rv_foto_mascota;
    public mascota_perfil_adaptador adaptador;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_perfil_mascota, container, false);

        rv_foto_mascota = (RecyclerView) v.findViewById(R.id.rv_foto_mascota);

        GridLayoutManager glm = new GridLayoutManager(getActivity(), 3);
        rv_foto_mascota.setLayoutManager(glm);

        inicializaDatos();
        inicializaAdaptador();

        return v;
    }


    public void inicializaAdaptador(){
        adaptador = new mascota_perfil_adaptador(fotos, getActivity());
        rv_foto_mascota.setAdapter(adaptador);
    }

    public void inicializaDatos() {
        fotos = new ArrayList<Mascota>();
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 1", 15));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 2", 22));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 3", 5));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 4", 11));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 5", 25));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 6", 6));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 7", 3));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 8", 23));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 9", 4));
        fotos.add(new Mascota(R.drawable.perro_hueso, "Perrito 10", 9));
    }
}