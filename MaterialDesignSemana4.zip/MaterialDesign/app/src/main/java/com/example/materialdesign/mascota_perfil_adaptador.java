package com.example.materialdesign;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class mascota_perfil_adaptador extends RecyclerView.Adapter<mascota_perfil_adaptador.MascotaPerfilViewHolder>  {

    ArrayList<Mascota> fotos;
    Activity activity;

    public mascota_perfil_adaptador(ArrayList<Mascota> fotos, Activity activity) {
        this.fotos = fotos;
        this.activity = activity;
    }

    @NonNull
    @Override
    public MascotaPerfilViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_cardview_imagen_mascota, parent, false);
        return new MascotaPerfilViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MascotaPerfilViewHolder mascotaViewHolder, int position) {
        final Mascota foto = fotos.get(position);
        mascotaViewHolder.img_mascota.setImageResource(foto.getFoto());
        //mascotaViewHolder.tvNombreCV.setText(mascota.getNombre());
        mascotaViewHolder.tv_rank_mascota.setText(Integer.toString(foto.getPuntos()));

    }

    @Override
    public int getItemCount() {
        return fotos.size();
    }


    public static class MascotaPerfilViewHolder extends RecyclerView.ViewHolder {

        private final ImageView img_mascota;
        private final TextView tv_rank_mascota;


        public MascotaPerfilViewHolder(@NonNull View itemView) {
            super(itemView);
            img_mascota = (ImageView) itemView.findViewById(R.id.img_mascota);
            tv_rank_mascota = (TextView) itemView.findViewById(R.id.tv_rank_mascota);

        }
    }
}
